function setPicture() {
    var img = document.getElementById("avatar");
    var value = avatarSelect.options[avatarSelect.selectedIndex].value;
    img.src = value;
}

function showStatusTrampo() {
    $("#statusTrampo").show();


}

function subiudelevel() {
    Swal.fire({
        title: 'Parabéns!!!! <br> Você subiu de nível.',
        width: 600,
        padding: '3em',
        background: '#fff ',
        backdrop: `
          rgba(0,0,123,0.4)
          url("https://media3.giphy.com/media/3ohhwzIw3bISRhQWME/source.gif")
          center 
          repeat
        `
    })
}


function cadastraTrampo() {
    Swal.fire({
        type: 'sucess',
        title: 'Trampo Criado com sucesso',
        text: 'Irá para avaliação!!',

    })
}

function getval(sel) {

    $("#infoTrampo").show();
    var res = "success";

}