<?php
$servidor = "localhost";
$usuario ="u691394038_aramu";
$senha ="467415ss";
$db = "u691394038_game";



$conexao = mysqli_connect($servidor,$usuario,$senha,$db);


if(isset($_COOKIE['logado'])){
    $login_cookie = $_COOKIE['logado'];
    $query = "SELECT * from usuario,personagem_necessidades,personagem_status WHERE usuario.id = $login_cookie and personagem_necessidades.id_usuario = $login_cookie and personagem_status.id_usuario = $login_cookie";
    $consultaTudo = mysqli_query($conexao, $query);
}
?>