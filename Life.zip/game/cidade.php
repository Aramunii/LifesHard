<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">

            <div class="card" style="text-align:center">



                <div class="row">

                    <div class="col-sm-12">
                        <img src="./img/icons/city.png" width="64px" height="54px">
                        <h1 style="font-weight: bold;font-size: 42px;">Cidade</h1>

                    </div>
                </div>

                <button class="btn d-lg-none" type="button" data-toggle="collapse" data-target="#example-collapse">
                        <h2>Menu</h2>
                    <span class="navbar-light"><span class="navbar-toggler-icon"></span></span>
                </button>


                <div id="example-collapse" class="collapse d-lg-block">
                    <!-- your card here -->

                    <div class="row">

                        <div class="col-sm-1">

                        </div>
                        <div class="col-sm-2">
                            <div class="card">
                                <div class="card-body">
                                    <img src="./img/icons/work.png">
                                    <h4 class="card-title" style="font-weight: bold;font-size: 15px;">Trabalhos</h4>
                                    <h5 class="card-title">Procure um trabalho <br> para ter uma renda fixa</h5>

                                    <a href="?pagina=trabalhos" class="btn btn-primary" style="font-size:18px;">Entrar</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="card">
                                <div class="card-body">
                                    <img src="./img/icons/bicos.png">
                                    <h4 class="card-title" style="font-weight: bold;font-size: 15px;">Trampos </h4>
                                    <h5 class="card-title">Se está precisando de uns trocados é por aqui que começará</h5>
                                    <a href="?pagina=bicos" class="btn btn-primary" style="font-size:18px">Entrar</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="card">
                                <div class="card-body">
                                    <img src="./img/icons/gym.png">
                                    <h4 class="card-title" style="font-weight: bold;font-size: 15px;">Academia</h4>
                                    <h5 class="card-title">Está procurando uma academia ?<br><br><br>
                                    <a href="?pagina=academia" class="btn btn-primary" style="font-size:18px;">Entrar</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-2">
                            <div class="card">
                                <div class="card-body">
                                    <img src="./img/icons/lanchonete.png">
                                    <h4 class="card-title" style="font-weight: bold;font-size: 15px;">Lanchonete</h4>
                                    <h5 class="card-title">Bateu aquela fome?<br><br><br>
                                    <a href="?pagina=lanchonete" class="btn btn-primary" style="font-size:18px;">Entrar</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="card">
                                <div class="card-body">
                                    <img src="./img/icons/escola.png">
                                    <h4 class="card-title" style="font-weight: bold;font-size: 15px;">Escola</h4>
                                    <h5 class="card-title">Aprenda novas profissões!<br><br><br></h5>
                                    <a href="?pagina=escola" class="btn btn-primary" style="font-size:18px;">Entrar</a>
                                </div>
                            </div>
                        </div>


                    </div>

            






                <div class="row">

                    <div class="col-sm-1">

                    </div>
                    <div class="col-sm-2">
                    <div class="card">
                                <div class="card-body">
                                    <img src="./img/icons/hotel.png">
                                    <h4 class="card-title" style="font-weight: bold;font-size: 15px;">Hotel</h4>
                                    <h5 class="card-title">Descanse um pouco!</h5>
                                    <a href="?pagina=hotel" class="btn btn-primary" style="font-size:18px;">Entrar</a>
                                </div>
                            </div>
                    </div>
                    <div class="col-sm-2">
                        
                    </div>

                    <div class="col-sm-2">

                    </div>

                    <div class="col-sm-2">

                    </div>
                    <div class="col-sm-2">

                    </div>


                </div>
                </div>
            </div>

        </div>
        <div class="col-md-4">

            <?php include "views/personagem_lateral.php"; ?>
        </div>
    </div>
</div>
</div>