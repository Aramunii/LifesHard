<?php 
include "db.php";
if (isset($_COOKIE['logado'])) {
    $login_cookie = $_COOKIE['logado'];
    if (isset($login_cookie)) {
        $query = "SELECT * from personagem_moradia where personagem_moradia.id_usuario =$login_cookie  ";
        $consulta = mysqli_query($conexao, $query);
        while ($linha = mysqli_fetch_array($consulta)) {
                $moradia = $linha['tipo'];
            $valormoradia = $linha['valorMensal'];
        }
    }
}

if($moradia=="rua"){
    header('location:../index.php?pagina=rua');
}elseif($moradia=="aluguel"){
    header('location:../index.php?pagina=aluguel');
}else{
    header('location:../index.php?pagina=propria');
}