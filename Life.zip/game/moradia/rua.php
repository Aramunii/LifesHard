<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">

            <div class="card" style="text-align:center">



                <div class="row">

                    <div class="col-sm-12">
                        <img src="./img/icons/rua.png" width="64px" height="54px">
                        <h1 style="font-weight: bold;font-size: 22px;">Rua</h1>
                        <a href="?pagina=cidade" class="btn btn-primary" style="font-size:10px">Voltar para cidade</a>

                    </div>
                </div>

                


                <div id="example-collapse" class="">
                    <!-- your card here -->
                    <br>
                    <h1 style="font-weight: bold;font-size: 22px;">Você mora na rua!</h1>

                    <div class="row">



                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                <img src="./img/icons/dormirRua.png">
                                    <h4 class="card-title" style="font-weight: bold;font-size: 15px;">Descansar</h4>
                                    <h5 class="card-title">Dormir na rua pode ser perigoso!</h5>
                                    <form id='trabalho' method='post' action='process/dormir.php'>
                                    <button class="btn btn-primary btn-block" type="submit" style="font-size:17px">Dormir</button>
                                    </form>
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
            </div>

        </div>
        <div class="col-md-4">

            <?php include "views/personagem_lateral.php"; ?>
        </div>
    </div>
</div>
</div>