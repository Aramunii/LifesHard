<script type="text/javascript" src="./js/alertas.js"></script>
<script type="text/javascript" src="./js/criapersonagem.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript" src="./js/ajax.js"></script>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">

            <div class="card" style="text-align:center">

                <div class="row">

                    <div class="col-sm-12">
                        <a href="?pagina=cidade " class="btn btn-primary" style="font-size:12px">Voltar para cidade</a><br><br>
                        <img src="./img/icons/bicos.png" width="64px" height="54px">

                    </div>
                </div>



                <div class="row" style="text-align:center">


                    <div class="col-sm-1">

                    </div>
                    <div class="col-sm-10">


                        <a style="font-weight: bold;font-size: 24px;">Selecione um trampo</a><br>
                        <div class="card" id="statusTrampo" style="display: none;">



                            <?php
                            if (isset($_SESSION["executou"]) && $_SESSION["executou"]) {
                                echo "<div class='alert alert-success' role='alert'>";
                                echo "Você concluiu seu trampo com sucesso!<br>Aqui está:<br>";
                                echo "+ R$" . $_SESSION['dinheiroGanho'] . ",00<br>";
                                echo "+" . $_SESSION['experienciaGanha'] . " de Experiência<br>";
                            } else {
                                echo "<div class='alert alert-danger' role='alert'>";

                                echo "<h1>Energia suficiente<br></h1>
                                    <a href='?pagina=moradia' class='btn btn-primary' style='font-size:12px'>Vá para casa descansar!!</a><br><br>
                                    <a href='?pagina=hotel' class='btn btn-primary' style='font-size:12px'>Vá para o hotel descansar!!</a><br><br>

                                    ";
                            }

                            ?>
                        </div>

                    </div>
                    <?php
                    if (isset($_SESSION["subiudelevel"])  &&   $_SESSION["subiudelevel"] == 1) {

                        echo "   
                            <script>subiudelevel()</script>
             
                            ";
                        $_SESSION["subiudelevel"] = 0;
                    }


                    if (isset($_SESSION["newsession"])) {
                        if (isset($_SESSION["newsession"]) &&  $_SESSION["newsession"] == 1 ||  $_SESSION["newsession"] == 2) {

                            echo "   
                                        <script>showStatusTrampo()</script>
                         
                                        ";

                            $_SESSION["newsession"] = 0;
                        }
                    }


                    ?>



                    <form id='trabalho' method='post' action='game/doWork.php'>
                        <select onchange="getDados(this);" id="work" name="work" class="form-control" style="font-size:17px;height:45px">
                            <?php
                            include "db.php";
                            $consulta = mysqli_query($conexao, "SELECT *FROM work");

                            while ($dados = mysqli_fetch_array($consulta)) {
                                echo ("<option  value='" . $dados['id']  . "'. " . 'name=asuhdauh' . ">" . $dados['nome'] . "</option>");
                            }



                            ?>

                        </select>


                        <div class='table-responsive' id="tabela">

                        </div>

                        <button class="btn btn-primary btn-block" type="submit" style="font-size:17px">Trampar</button>
                    </form>

                </div>



            </div>
        </div>

    </div>
    <div class="col-md-4">

        <?php include "views/personagem_lateral.php"; ?>
    </div>
</div>
</div>
</div>