<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">

            <div class="card" style="text-align:center">



                <div class="row">

                    <div class="col-sm-12">
                        <img src="./img/icons/gym.png" width="64px" height="54px">
                        <h1 style="font-weight: bold;font-size: 42px;">Academia</h1>
                        <a href="?pagina=cidade" class="btn btn-primary" style="font-size:18px">Voltar para cidade</a>

                    </div>
                </div>
                <div class="row">
                <div class="col-sm-12">
                        <h1 class="card-title">PÁGINA EM CONSTRUÇÃO</h1>
                        <img src="./img/icons/construcao.png">
                        <p class="card-text">
                            O Life is Hard é um jogo ainda em desenvolvimento<br>



                        </p>
                    </div>


                </div>
            </div>

        </div>
        <div class="col-md-4">

            <?php include "views/personagem_lateral.php"; ?>
        </div>
    </div>
</div>
</div>