<?php
include '../db.php';
include 'getDados.php';
session_start();
$idWork = $_POST['work'];






$query = "SELECT * FROM work where id = '$idWork' ";

$verifica = mysqli_query($conexao, $query);
while ($linha = mysqli_fetch_array($verifica)) {
    $recompensaDinheiro = $linha['recompensa'];
    $experienciaWork = $linha['experiencia'];
    $energiaWork = $linha['energia'];
}

if ($energia >= $energiaWork) {




    $expMin += $experienciaWork;
    $dinheiro += $recompensaDinheiro;
    $energiaWork = $energia - $energiaWork;

    //atualiza status 

    $query = "UPDATE personagem_status SET expMin = $expMin , dinheiro = $dinheiro where id_usuario = $login_cookie ";

    $cadastra = mysqli_query($conexao, $query);

    //retira energia

    $query = "UPDATE personagem_necessidades SET energia = $energiaWork where id_usuario = $login_cookie ";

    $cadastra = mysqli_query($conexao, $query);

    //verifica se passou de level e seta na database.
    include 'getDados.php';

    if ($expMin > $expMax) {
        $expMin =  $expMin - $expMax;
        $level++;
        $expMax += 70;
        $_SESSION["subiudelevel"] = 1;
    } elseif ($expMin == $expMax) {
        $level++;
        $expMax += 70;
        $expMin = 0;
        $_SESSION["subiudelevel"] = 1;
    } else {
        $_SESSION["subiudelevel"] = 0;
    }


    $query = "UPDATE personagem_status SET expMin = $expMin , level =$level,expMax=$expMax where id_usuario = $login_cookie ";

    $cadastra = mysqli_query($conexao, $query);



    /*session is started if you don't write this line can't use $_Session  global variable*/
    $_SESSION["newsession"] = 1;

    //Status para o Aviso
    $_SESSION["experienciaGanha"] = $experienciaWork;
    $_SESSION["dinheiroGanho"] = $recompensaDinheiro;
    $_SESSION["executou"] = true;
} else {
    
    $_SESSION["executou"] = false;
     $_SESSION["newsession"] = 2;



 }




header('location:/index.php?pagina=bicos');
