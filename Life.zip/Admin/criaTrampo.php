<?php

include '../db.php';
session_start();

$nome = $_POST['nome'];
$energia = $_POST['energia'];
$recompensa = $_POST['recompensa'];
$experiencia = $_POST['experiencia'];
$fome = $_POST['fome'];
$diversao = $_POST['diversao'];
$social = $_POST['social'];
$peso = $_POST['peso'];
$ganhaFome = $_POST['ganhaFome'];
$ganhaSocial = $_POST['ganhaSocial'];
$ganhaPeso = $_POST['ganhaPeso'];
$ganhaDiversao = $_POST['ganhaDiversao'];

$strReplace = str_replace(",", ".", "$peso");
$strReplace = str_replace(",", ".", "$ganhaPeso");

if($fome==""){
    $fome=0;
}
if($diversao==""){
    $diversao=0;
}
if($social==""){
    $social=0;
}
if($peso==""){
    $peso=0;
}
if($ganhaFome==""){
    $ganhaFome=0;
}
if($ganhaSocial==""){
    $ganhaSocial=0;
}
if($ganhaPeso==""){
    $ganhaPeso=0;
}
if($ganhaDiversao==""){
    $ganhaDiversao=0;
}





$query = "INSERT INTO work(nome, recompensa, experiencia, energia, fome, diversao, social, peso, ganhaFome, ganhaDiversao, ganhaSocial, ganhaPeso)
          VALUES('$nome','$recompensa','$experiencia','$energia','$fome','$diversao','$social','$peso','$ganhaFome','$ganhaDiversao','$ganhaSocial','$ganhaPeso')";

$cadastra = mysqli_query($conexao, $query);


$_SESSION["criou"]=1;



header('location:../index.php?pagina=adminTrampo');
