<script type="text/javascript" src="./js/avatar.js"></script>
<script type="text/javascript" src="./js/criapersonagem.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="text-align:center">
                <a href="?pagina=adminInicial" class="btn btn-primary" style="font-size:18px">Voltar ao painel de Admin</a>
                <div class="row">

                    <div class="col-sm-2">
                    </div>
                    <div class="col-sm-8">


                        <form method="post"  style="text-align:center" action="Admin/criaTrampo.php">


                            <h2 id="titulo">Criar novo Trampo</h2>
                            <div class="illustration"><i class="icon ion-ios-locked-outline"></i></div>

                            <div class="table-responsive" >
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-group">
                                                <label style="font-size:10px">Nome trampo</label>
                                                    <input class="form-control" type="text" name="nome" placeholder="Nome Trampo"  required />
                                                </div>
                                                <div class="form-group">
                                                <label style="font-size:10px">Energia gasta</label>
                                                    <input class="form-control" type="number" name="energia" placeholder="Energia Gasta"  required />
                                                </div>
                                            </th>
                                            <th>
                                                <div class="form-group">
                                                <label style="font-size:10px;">Dinheiro ganho</label>
                                                    <input class="form-control" type="number" name="recompensa" placeholder="R$ ganho"  required />
                                                </div>
                                                <div class="form-group">
                                                <label style="font-size:10px">Exp ganho</label>
                                                    <input class="form-control" type="number" name="experiencia" placeholder="Exp ganho"  required />
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th>
                                                <label>Diminiu a barra</label>
                                                <div class="form-group">
                                                    <input class="form-control" type="number" name="fome" placeholder=" Fome" />
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control" type="number" name="diversao" placeholder=" Diversão"   />
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control" type="number" name="social" placeholder=" Social"   />
                                                </div>
                                                <div class="form-group">
                                                <label style="font-size:10px;">Ganha peso</label>

                                                    <input class="form-control" type="number" name="peso" placeholder="Ganha Peso"   step="0.010"/>
                                                </div>
                                            </th>
                                            <th>
                                            <label>Aumenta a barra</label>
                                            <div class="form-group">
                                                    <input class="form-control" type="number" name="ganhaFome" placeholder=" Fome"   />
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control" type="number" name="ganhaDiversao" placeholder=" Diversão"  />
                                                </div>
                                                <div class="form-group">
                                                    <input class="form-control" type="number" name="ganhaSocial" placeholder=" Social"   />
                                                </div>
                                                <div class="form-group">
                                                <label style="font-size:10px;">Perde peso</label>

                                                    <input class="form-control" type="number" name="ganhaPeso" placeholder="Perde Peso" step="0.010"   />
                                                </div>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th>
                                               
                                            </th>
                                            <th>

                                            </th>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>



                            <div class="form-group"><button class="btn btn-primary btn-block" type="submit" value="cadastrar" id="cadastrar" name="cadastrar">Criar Trampo</button>


                            </div>


                        </form>


                        <?php
                        if(isset($_SESSION["criou"])  &&   $_SESSION["criou"]==1){
                                
                            echo "   
                            <script>cadastraTrampo()</script>
             
                            ";
                            $_SESSION["criou"]=0;
                        }?>








                    </div>
                </div>


            </div>

        </div>
        <div class="col-md-4">


        </div>
    </div>
</div>
</div>