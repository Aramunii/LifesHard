<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="text-align:center">

                <div class="row">

                    <div class="col-sm-12">
                        <img src="./img/icons/work.png" width="64px" height="54px">

                        <h1 style="font-weight: bold;font-size: 42px;">Criar Trampo</h1>
                        <a href="?pagina=adminTrampo" class="btn btn-primary" style="font-size:18px">Entrar</a>
                    </div>
                </div>


            </div>

        </div>
        <div class="col-md-4">


        </div>
    </div>
</div>
</div>