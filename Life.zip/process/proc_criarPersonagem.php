<?php

include '../db.php';

$query = "SELECT * FROM mundo ";

$verifica = mysqli_query($conexao, $query);
if (mysqli_num_rows($verifica) <= 0) { } else {
    while ($linha = mysqli_fetch_array($verifica)) {
        $dia_mundo = $linha['dia'];  #pega a data no banco de dados
        $mes_mundo = $linha['mes'];
        $ano_mundo = $linha['ano'];
    }
}

#seta as variaveis do personagem
$nome = $_POST['nome_personagem'];
$cor = $_POST['cor'];
$genero = $_POST['genero'];
$dia = $_POST['dia'];
$mes = $_POST['mes'];
$avatar=$_POST['avatar'];
$peso =$_POST['peso'];
$altura =$_POST['altura'];
$login_cookie = $_COOKIE['logado'];
$tipo=$_POST['tipo'];
$idade = mt_rand(16, 25); 
$ano_nasc = $ano_mundo - $idade;


$strReplace = str_replace(",", ".", "$peso");
$strReplace = str_replace(",", ".", "$altura");

$alturaIMC = $altura*$altura;
$imc = $peso / $alturaIMC;

if($tipo=="descolado"){
    $int = 1;
    $res = 3;
    $for = 2;
    $car = 5;
}elseif($tipo=="nerd"){
    $int = 5;
    $res = 2;
    $for = 2;
    $car = 1;
}
elseif($tipo=="atleta"){
    $int = 2;
    $res = 3;
    $for = 4;
    $car = 3;
}
elseif($tipo=="normal"){
    $int =2;
    $res = 2;
    $for = 2;
    $car = 2;
}





$query = "INSERT INTO personagem(id_usuario,nome_personagem,idade,genero,cor,dia_nasc,mes_nasc,ano_nasc,avatar,peso,altura,imc)
          VALUES('$login_cookie','$nome','$idade','$genero','$cor','$dia','$mes','$ano_nasc','$avatar','$peso','$altura','$imc')";

$cadastra = mysqli_query($conexao, $query);


 $query = "INSERT INTO personagem_status(id_usuario,inteligencia,resistencia,forca,carisma)
 VALUES('$login_cookie','$int','$res','$for','$car')";

$cadastraStatus = mysqli_query($conexao, $query);

$query = "INSERT INTO personagem_necessidades(id_usuario)
          VALUES('$login_cookie')";

$cadastraNecessidade = mysqli_query($conexao, $query);

$query = "INSERT INTO personagem_moradia(id_usuario,tipo,valorMensal)
          VALUES('$login_cookie','rua','0')";

$cadastraMoradia = mysqli_query($conexao, $query);





header('location:../index.php?pagina=home');
