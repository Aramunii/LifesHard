<div class="login-dark">
    <form method="post" action="process/proc_login.php">
        <h2 id="titulo">Login</h2>
        <div class="illustration"><i class="icon ion-ios-locked-outline"></i></div>
        <div class="form-group"><input class="form-control" type="text" name="login" placeholder="Usuário" /></div>
        <div class="form-group"><input class="form-control" type="password" name="senha" placeholder="Senha" /></div>
        <div class="form-group"><button class="btn btn-primary btn-block" type="submit" value="logar" id="logar" name="logar">Logar</button>
        
        <div class='btn btn-secundary btn-block' role='presentation'><a class='nav-link' href='?pagina=cadastro' style="color:white">Cadastrar</a></div>
    </div>
    </form>
    
</div>