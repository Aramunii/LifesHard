<div class="login-dark">
    <form method="post" action="process/proc_logout.php">
        <h2 id="titulo">Logout</h2>
        <br>
        <h3 id="titulo">Deseja realmente sair do jogo?<h3>
        <div class="illustration"><i class="icon ion-ios-locked-outline"></i></div>
        <div class="form-group"><button class="btn btn-primary btn-block" type="submit" value="logar" id="logar" name="logar">Sim</button>
         <div class='btn btn-secundary btn-block' role='presentation'><a class='nav-link' href='?pagina=home' style="color:white">Não</a></div>
        </div>
    </form>
</div>