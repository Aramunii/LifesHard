<?php
include 'db.php';


include 'header.php'; #coloca o cabeçalho fixo

#Conteudo da pagina
if (isset($_GET['pagina'])) {
    $pagina = $_GET['pagina'];
} else {
    $pagina = 'home';
}

switch ($pagina) {
    case 'logout':
        include 'views/logout.php';
        break;
    case 'logoutYes':
        include 'process/proc_logout.php';
        break;
    case 'login':
        include 'views/login.php';
        break;
    case 'cadastro':
        include 'views/cadastro.php';
        break;
    case 'criaPersonagem';
        include 'game/criaPersonagem.php';
        break;
    case 'personagem';
        include 'views/personagem.php';
        break;
    case 'mundo';
        include 'views/mundo.php';
        break;
    case 'cidade';
        include 'game/cidade.php';
        break;
    case 'trabalhos';
        include 'game/cidade/trabalhos.php';
        break;
    case 'bicos';
        include 'game/cidade/bicos.php';
        break;
    case 'escola';
        include 'game/cidade/escola.php';
        break;
    case 'lanchonete';
        include 'game/cidade/lanchonete.php';
        break;
    case 'academia';
        include 'game/cidade/academia.php';
        break;
    case 'hotel';
        include 'game/cidade/hotel.php';
        break;
    case 'moradia';
        include 'game/moradia.php';
        break;
    case 'rua';
        include 'game/moradia/rua.php';
        break;
    case 'propria';
        include 'game/moradia/rua.php';
        break;
    case 'propria';
        include 'game/moradia/propria.php';
        break;





    case 'adminInicial';
        include 'Admin/inicial.php';
        break;
    case 'adminTrampo';
        include 'Admin/adminTrampo.php';
        break;


    default:
        include 'views/home.php';
        break;
}


include "footer.php";
