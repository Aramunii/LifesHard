<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">

            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Title</h4>
                    <h6 class="text-muted card-subtitle mb-2">Subtitle</h6>
                    <p class="card-text">Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p><a class="card-link" href="#">Link</a><a class="card-link" href="#">Link</a>
                </div>
            </div>

        </div>
        <div class="col-md-4">
            
                <?php include "views/personagem_lateral.php"; ?>
            </div>
        </div>
    </div>
</div>