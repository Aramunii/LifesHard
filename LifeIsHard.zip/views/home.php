<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">
            <div class="card" style="text-align:center">
                <div class="card-body">
                    <h1 class="card-title">Bem vindo!</h1>
                    <h6 class="card-subtitle mb-2">MMORPG TEXT BROWSER</h6>
                    <p class="card-text">
                        O Life is Hard é um jogo ainda em desenvolvimento<br>
                        


                    </p>
                </div>
            </div>

        </div>
        <div class="col-md-4">
            
                <?php 
                if (isset($_COOKIE['logado'])) {
                    $login_cookie = $_COOKIE['logado'];
                    if (isset($login_cookie)) {
                        include "views/personagem_lateral.php"; 
                    }   
                } else {
                    
                    include "views/login-home.php";
                }
                
           
                ?>
            </div>
        </div>
    </div>
</div>