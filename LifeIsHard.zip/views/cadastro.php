<div class="login-dark">
    <form method="post" action="process/proc_cadastro.php">

            
        <h2 id="titulo">Cadastro</h2>
        <div class="illustration"><i class="icon ion-ios-locked-outline"></i></div>
        <div class="form-group"><input class="form-control" type="text" name="usuario" placeholder="Usuário"  required/></div>
        <div class="form-group"><input class="form-control" type="password" name="senha" placeholder="Senha" required /></div>
        <div class="form-group"><input class="form-control" type="text" name="email" placeholder="E-mail" required /></div>

        <div class="form-group"><button class="btn btn-primary btn-block" type="submit" value="cadastrar" id="cadastrar" name="cadastrar">Cadastrar</button>
            

        </div>

        
    </form>
  
    </div>

</div>