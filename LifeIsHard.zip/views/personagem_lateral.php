<?php
if (isset($_COOKIE['logado'])) {
    $login_cookie = $_COOKIE['logado'];
    if (isset($login_cookie)) {
        $query = "SELECT * from personagem,personagem_necessidades,personagem_status where personagem.id_usuario= $login_cookie 
        and personagem_necessidades.id_usuario= $login_cookie 
        and personagem_status.id_usuario =$login_cookie  ";
        $consulta = mysqli_query($conexao, $query);
        while ($linha = mysqli_fetch_array($consulta)) {
            $nome_personagem = $linha['nome_personagem'];
            $idade = $linha['idade'];
            $genero = $linha['genero'];
            $cor = $linha['cor'];
            $dia_nasc = $linha['dia_nasc'];
            $mes_nasc = $linha['mes_nasc'];
            $ano_nasc = $linha['ano_nasc'];
            $diversao = $linha['diversao'];
            $social = $linha['social'];
            $fome = $linha['fome'];
            $energia = $linha['energia'];
            $vida = $linha['vida'];
            $dinheiro = $linha['dinheiro'];
            $conduta = $linha['conduta'];
            $expMin = $linha['expMin'];
            $expMax = $linha['expMax'];
            $level = $linha['level'];
            $avatar = $linha['avatar'];
            $imc = $linha['imc'];
            $peso = $linha['peso'];
            $altura = $linha['altura'];
            $inteligencia= $linha['inteligencia'];
            $resistencia=$linha['resistencia'];
            $forca=$linha['forca'];
            $carisma=$linha['carisma'];
        }
    }
}
if ($diversao >= 70) {
    $diversao_status = "green";
} elseif ($diversao < 70 && $diversao > 40) {
    $diversao_status =   "yellow";
} elseif ($diversao < 40) {
    $diversao_status =   "red";
}

if ($fome >= 70) {
    $fome_status = "green";
} elseif ($fome < 70 && $fome > 40) {
    $fome_status =   "yellow";
} elseif ($fome < 40) {
    $fome_status =   "red";
}
if ($energia >= 70) {
    $energia_status = "green";
} elseif ($energia < 70 && $energia > 40) {
    $energia_status =   "yellow";
} elseif ($energia < 40) {
    $energia_status =   "red";
}
if ($social >= 70) {
    $social_status = "green";
} elseif ($social < 70 && $social > 40) {
    $social_status =   "yellow";
} elseif ($social < 40) {
    $social_status =   "red";
}
if ($vida >= 70) {
    $vida_status = "green";
} elseif ($vida < 70 && $vida > 40) {
    $vida_status =   "yellow";
} elseif ($vida < 40) {
    $vida_status =   "red";
}
if ($conduta >= 70) {
    $conduta_status = "green";
    $conduta_texto = "Boa";
} elseif ($conduta < 70 && $conduta > 40) {
    $conduta_status =   "grey";
    $conduta_texto = "Neutra";
} elseif ($conduta < 40) {
    $conduta_status =   "red";
    $conduta_texto = "Ruim";
}

if ($imc < 19) {

    $imc_status = "Magro";
} elseif (($imc > 19) and ($imc < 25)) {

    $imc_status = "Normal";
} elseif (($imc > 25) and ($imc < 30)) {

    $imc_status = "Sobrepeso";
} else {
    $imc_status = "Obeso";
}




?>


<div class="card">
    <div class="card-body">
        <h4 class="card-title" style="text-align:center">Personagem</h4>


        <?php
        echo "
        <div class='container-fluid' style='text-align:center'>
                    <div class='row'>
                        <div class='col-md-12'>
                        <img src='$avatar' width='160px' height='160px'> <br><br>
                        </div>
                    </div>
                    </div>
                    
                    
            <h1 class='card-subititle' style='text-align:center'> $nome_personagem
             <br>$idade anos </h1>
           
                <div class='card-text' style='text-align:center'>
                          
                         
                            <div class='row'>
                                <div class='col-md-6'>
                                <label class='card-text'>Level: $level </label><br>
                                <label class='card-text'>Exp: $expMin/$expMax </label><br>
                                <label class='card-text'>Dinheiro: R$ $dinheiro,00</label><br>
                                <br>
                                </div>
                                <div class='col-md-6'>
                                <label class='card-text'>Altura: $altura m </label><br>
                                <label class='card-text'>Peso: $peso kg </label><br>
                                <label class='card-text'> $imc_status </label><br>

                                
                                </div>
                            </div>
                        
              
                    
                    <div class='container-fluid' style='text-align:center'>
                                      <div class='row'>
                        <div class='col-md-4'>
                        <label >Vida</label>
                            <div class='progress' style='height:29px'>
                                <div class='progress-bar' aria-valuenow='$vida' aria-valuemin='0' aria-valuemax='100' style='width: $vida%;background-color:$vida_status'>$vida%</div>
                                </div>
                              <label>Conduta: $conduta_texto</label>
                                <div class='progress' style='height:29px'>
                                    <div class='progress-bar' aria-valuenow='$conduta' aria-valuemin='0' aria-valuemax='100' style='width: $conduta%;background-color:$conduta_status'>$conduta%</div>
                                    </div>
                        </div>
                        <div class='col-md-8'>
                        <label class='card-text' style='text-align:center'>Status</label>
                        <div class='table-responsive'>
                            <table class='table' style='font-weight:bold' >
                                <thead>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Inteligência</td>
                                        <td>Resistência</td>
                                    </tr>
                                    <tr>
                                        <td>$inteligencia</td>
                                        <td>$resistencia</td>
                                    </tr>
                                    <tr>
                                    <td>Força</td>
                                    <td>Carisma</td>
                                </tr>
                                <tr>
                                    <td>$forca</td>
                                    <td>$carisma</td>
                                </tr>

                                    
                                </tbody>
                            </table>
                        </div>
                        

                   
                    </div>
                    </div>
                </div>                    
                    
                </div> 
                    
                        <div class='table-responsive'>
                            <table class='table'  style='text-align:center;'>
                                <thead>
                                    <tr></tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                        <label >Energia </label>
                                        <div class='progress' style='height:29px'>
                                        <div class='progress-bar' aria-valuenow='$energia' aria-valuemin='0' aria-valuemax='100' style='width: $energia%;background-color:$energia_status'>$energia%</div>
                                        </div>
                                        </td>
                                        <td>
                                        <label >Fome    </label>
                                        <div class='progress' style='height:29px'>
                                        <div class='progress-bar' aria-valuenow='$fome' aria-valuemin='0' aria-valuemax='100' style='width: $fome%;background-color:$fome_status'>$fome%</div>
                                        </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <label >Diversão</label>
                                        <div class='progress' style='height:29px'>
                                        <div class='progress-bar' aria-valuenow='$diversao' aria-valuemin='0' aria-valuemax='100' style='width: $diversao%; background-color:$diversao_status'>$diversao%</div>
                                        </div>
                                        </td>
                                        <td>
                                        <label >Social   </label>
                                        <div class='progress' style='height:29px'>
                                        <div class='progress-bar' aria-valuenow='$social' aria-valuemin='0' aria-valuemax='100' style='width: $social%; background-color:$social_status'>$social%</div>
                                        </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>               
                
               
    
        
        
        "; ?>


    </div>
</div>