<?php
$servidor = "localhost";
$usuario ="id10057083_maer";
$senha ="467415ss";
$db = "id10057083_lifeishardgame";



$conexao = mysqli_connect($servidor,$usuario,$senha,$db);


if(isset($_COOKIE['logado'])){
    $login_cookie = $_COOKIE['logado'];
    $query = "SELECT * from usuario,personagem_necessidades,personagem_status WHERE usuario.id = $login_cookie and personagem_necessidades.id_usuario = $login_cookie and personagem_status.id_usuario = $login_cookie";
    $consultaTudo = mysqli_query($conexao, $query);
}
?>