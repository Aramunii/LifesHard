<!DOCTYPE html>
<html>

<head>
    <title> Life is Hard</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilo.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<header>
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-6 col-lg-12">
    <a href="?pagina=home"><img src="img/logo.png" title="Logo" alt="Logo" width="120px" height="100px"></a>
        <div id="menu">
            <?php
            if (isset($_COOKIE['logado'])) {
                $login_cookie = $_COOKIE['logado'];
                if (isset($login_cookie)) {
                    echo " 
                        <a href='?pagina=personagens'>Personagem</a>                      
                        <a href='?pagina=logout'>Logout</a> 
                        ";
                    $logado = true;
                }
            } else {
                echo "  <a href='?pagina=login'>Login</a> ";
            }
            echo "<li class='dropdown'>
            <a class='dropdown-toggle nav-link dropdown-toggle' data-toggle='dropdown' aria-expanded='false' href='#'>Menu </a>
            <div class='dropdown-menu' role='menu'>
            <a class='dropdown-item' role='presentation' href='#'>Ajuda</a>
            <a class='dropdown-item' role='presentation' href='#'>Opcões</a>
            <a class='dropdown-item' role='presentation' href='?pagina=logout'>Logout</a>
            </div>
            </li>
        ";
            ?>

        </div>
    </div></div>
    
  </div>
  
</div>

</header>
<div id="conteudo" class="container-fluid">
  