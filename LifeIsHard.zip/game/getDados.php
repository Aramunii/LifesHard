<?php

include "../db.php";
if (isset($_COOKIE['logado'])) {
    $login_cookie = $_COOKIE['logado'];
    if (isset($login_cookie)) {
        $query = "SELECT * from personagem,personagem_necessidades,personagem_status where personagem.id_usuario= $login_cookie 
       and personagem_necessidades.id_usuario= $login_cookie 
       and personagem_status.id_usuario =$login_cookie  ";
        $consulta = mysqli_query($conexao, $query);
        while ($linha = mysqli_fetch_array($consulta)) {
            $nome_personagem = $linha['nome_personagem'];
            $idade = $linha['idade'];
            $genero = $linha['genero'];
            $cor = $linha['cor'];
            $dia_nasc = $linha['dia_nasc'];
            $mes_nasc = $linha['mes_nasc'];
            $ano_nasc = $linha['ano_nasc'];
            $diversao = $linha['diversao'];
            $social = $linha['social'];
            $fome = $linha['fome'];
            $energia = $linha['energia'];
            $vida = $linha['vida'];
            $dinheiro = $linha['dinheiro'];
            $conduta = $linha['conduta'];
            $expMin = $linha['expMin'];
            $expMax = $linha['expMax'];
            $level = $linha['level'];
            $avatar = $linha['avatar'];
            $imc = $linha['imc'];
            $peso = $linha['peso'];
            $altura = $linha['altura'];
            $inteligencia = $linha['inteligencia'];
            $resistencia = $linha['resistencia'];
            $forca = $linha['forca'];
            $carisma = $linha['carisma'];
        }
    }
}
if (isset($_GET["txtnome"])) {

    $nome = $_GET["txtnome"];



    $consulta = mysqli_query($conexao, "SELECT * FROM work where id= '$nome'");

    while ($dados = mysqli_fetch_array($consulta)) {
        session_start();
        $energia =  $dados['energia'];
        $dinheiro = $dados['recompensa'];
        $experiencia = $dados['experiencia'];

        echo "    <table class='table' style='font-weight:bold'>
                                        <thead>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Energia Requerida:</td>
                                                <td>$energia</td>
                                            </tr>
                                            <tr>
                                            <td>Exp:</td>
                                            <td>$experiencia</td>
                                        </tr>
                                            <tr>
                                                <td>Recompensa:</td>
                                                <td>R$ $dinheiro,00</td>
                                            </tr>
                                           
    
    
                                        </tbody>
                                    </table>";
    }
}
