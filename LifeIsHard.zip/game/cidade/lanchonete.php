<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">

            <div class="card" style="text-align:center">



                <div class="row">

                    <div class="col-sm-12">
                        <img src="./img/icons/lanchonete.png" width="64px" height="54px">
                        <h1 style="font-weight: bold;font-size: 42px;">Lanchonete</h1>
                        <a href="?pagina=cidade" class="btn btn-primary" style="font-size:18px">Voltar para cidade</a>

                    </div>
                </div>
                <div class="row">

                    <div class="col-sm-1">

                    </div>
                    <div class="col-sm-2">
                        <div class="card">
                            <div class="card-body">
                                <img src="./img/icons/.png">
                                <h4 class="card-title" style="font-weight: bold;font-size: 22px;">                                </h4>
                                <h5 class="card-title"></h5>

                                <a href="" class="btn btn-primary" style="font-size:18px">Entrar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="card">
                            <div class="card-body">
                                <img src="./img/icons/.png">
                                <h4 class="card-title" style="font-weight: bold;font-size: 22px;"> </h4>
                                <h5 class="card-title"></h5>
                                <a href="" class="btn btn-primary" style="font-size:18px">Entrar</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-2">
                        <div class="card">
                            <div class="card-body">
                                <img src="./img/icons/.png">
                                <h4 class="card-title" style="font-weight: bold;font-size: 22px;"></h4>
                                <h5 class="card-title"></h5>
                                <a href="" class="btn btn-primary" style="font-size:18px">Entrar</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-2">
                        <div class="card">
                            <div class="card-body">
                                <img src="./img/icons/.png">
                                <h4 class="card-title" style="font-weight: bold;font-size: 22px;"></h4>
                                <h5 class="card-title"></h5>
                                <a href="" class="btn btn-primary" style="font-size:18px">Entrar</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="card">
                            <div class="card-body">
                                <img src="./img/icons/.png">
                                <h4 class="card-title" style="font-weight: bold;font-size: 22px;" style="font-weight: bold;font-size: 22px;"></h4>
                                <h5 class="card-title"></h5>
                                <a href="" class="btn btn-primary" style="font-size:18px">Entrar</a>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </div>
        <div class="col-md-4">

            <?php include "views/personagem_lateral.php"; ?>
        </div>
    </div>
</div>
</div>