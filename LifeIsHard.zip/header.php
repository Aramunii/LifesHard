<?php
session_start();
if (isset($_COOKIE['logado'])) {
    $login_cookie = $_COOKIE['logado'];
    if (isset($login_cookie)) {
        $logado = true;
    }
} else {
    $logado = false;
}

?>

<html>
<script type="text/javascript" src="./js/avatar.js"></script>
<script type="text/javascript" src="./js/criapersonagem.js"></script>
<head>
    <title> Life is Hard</title>
    <meta charset="UTF-8">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="css/estilo.css">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <header>
        <a class="navbar-brand" href="index.php?pagina=home" style="background-color:#105e85;margin:0px">
            <img src="img/logo2.png" width="65px">
        </a>
     

        <div id="teste" style="background-color:#105e85">
            <nav class="navbar navbar-light navbar-expand-md navigation-clean">

                <div class="container">


                    <button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav ml-auto">
                            <?php
                            if ($logado) {
                                echo "<li class='nav-item' role='presentation'><a class='nav-link' href='?pagina=personagem'>Personagem</a></li>";
                                echo "<li class='nav-item' role='presentation'><a class='nav-link' href='?pagina=mundo'>Mundo</a></li>";
                                echo "<li class='nav-item' role='presentation'><a class='nav-link' href='?pagina=logout'>Logout</a></li>";
                            } else {
                                echo "<li class='nav-item' role='presentation'><a class='nav-link' href='?pagina=login'>Login</a></li>";
                            }
                            ?>


                        </ul>
                    </div>
                </div>
            </nav>
        </div>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    </header>

</body>
<div id="conteudo" class="container-fluid">