
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-sm-6 col-lg-12">
        
    <footer class="container-fluid">
    <h6>Tilin Studios™ - Todos os direitos reservados </h6>
    </footer></div>


</div>
</div>
</html>