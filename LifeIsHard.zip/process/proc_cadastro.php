<?php

include '../db.php';


$login = $_POST['usuario'];
$senha = $_POST['senha'];
$email = $_POST['email'];

$query = "INSERT INTO usuario(usuario,senha,email)
          VALUES('$login','$senha','$email')";

$cadastra = mysqli_query($conexao, $query);



$query = "SELECT * FROM usuario WHERE usuario = '$login' ";

$verifica = mysqli_query($conexao, $query);
if (mysqli_num_rows($verifica) <= 0) {
  
} else {
    while ($linha = mysqli_fetch_array($verifica)) {
        $expire = time() + 60 * 60 * 24 * 30;
        setcookie("logado", $linha['id'], $expire, '/');
    }
}




header('location:../index.php?pagina=criaPersonagem');
