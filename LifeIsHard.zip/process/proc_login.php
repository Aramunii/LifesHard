<?php
include '../db.php';

session_start();

$login = $_POST['login'];
$entrar = $_POST['logar'];
$senha = $_POST['senha'];

    $query = "SELECT * FROM usuario WHERE usuario = '$login' AND senha = '$senha'";

    $verifica = mysqli_query($conexao, $query) or die("erro ao selecionar");
    if (mysqli_num_rows($verifica) <= 0) {
        header('Location:../index.php?pagina=login');
    } else {

        while ($linha = mysqli_fetch_array($verifica)) {
            $expire = time() + 60 * 60 * 24 * 30;
            setcookie("logado", $linha['id'], $expire, '/');
        }


        header('Location:../index.php?pagina=index.php');
    }

?>