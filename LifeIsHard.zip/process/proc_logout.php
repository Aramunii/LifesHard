<?php
unset($_COOKIE['logado']);
setcookie('logado','',time() -3600, '/');
header('Location:/index.php?pagina=loginUsuario');
?>