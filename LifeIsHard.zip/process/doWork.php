<?php
include '../db.php';

$idWork = $_POST['work'];


$query = "SELECT * FROM work where id = '$idWork' ";

$verifica = mysqli_query($conexao, $query);
while($linha = mysqli_fetch_array($verifica)){
   $recompensaDinheiro = $linha['recompensa'];
   $experienciaWork = $linha['experiencia'];
}

if (isset($_COOKIE['logado'])) {
   $login_cookie = $_COOKIE['logado'];
   if (isset($login_cookie)) {
       $query = "SELECT * from personagem,personagem_necessidades,personagem_status where personagem.id_usuario= $login_cookie 
       and personagem_necessidades.id_usuario= $login_cookie 
       and personagem_status.id_usuario =$login_cookie  ";
       $consulta = mysqli_query($conexao, $query);
       while ($linha = mysqli_fetch_array($consulta)) {
           $nome_personagem = $linha['nome_personagem'];
           $idade = $linha['idade'];
           $genero = $linha['genero'];
           $cor = $linha['cor'];
           $dia_nasc = $linha['dia_nasc'];
           $mes_nasc = $linha['mes_nasc'];
           $ano_nasc = $linha['ano_nasc'];
           $diversao = $linha['diversao'];
           $social = $linha['social'];
           $fome = $linha['fome'];
           $energia = $linha['energia'];
           $vida = $linha['vida'];
           $dinheiro = $linha['dinheiro'];
           $conduta = $linha['conduta'];
           $expMin = $linha['expMin'];
           $expMax = $linha['expMax'];
           $level = $linha['level'];
           $avatar = $linha['avatar'];
           $imc = $linha['imc'];
           $peso = $linha['peso'];
           $altura = $linha['altura'];
           $inteligencia= $linha['inteligencia'];
           $resistencia=$linha['resistencia'];
           $forca=$linha['forca'];
           $carisma=$linha['carisma'];
       }
   }
}


$expMin += $experienciaWork;
$dinheiro += $recompensaDinheiro;


$query = "UPDATE personagem_status SET expMin = $expMin , dinheiro = $dinheiro where id_usuario = $login_cookie "; 

$cadastra = mysqli_query($conexao, $query);



$_SESSION['msg']=true;

header('location:/index.php?pagina=work');



?>